
const express = require("express");
const router = express.Router();
<<<<<<< HEAD
 
const registerRouter=require("../controllers/user/authController");
=======
const { Users } = require("../models");
const bcrypt = require("bcrypt");
const { validateToken } = require("../../config/middlewares/AuthMiddleware");
const { sign } = require("jsonwebtoken");

router.post("/", async (req, res) => {
  const { username, email, password } = req.body;

  const duplicaterUser = await Users.findOne({ where: { username: username } });
  if(duplicaterUser) return res.json("user already registered");

  try{
  bcrypt.hash(password, 10).then((hash) => {
    Users.create({
      username: username,
      email: email,
      password: hash,
    });
    res.json("SUCCESS");
  });
}
catch(err){
  res.status(500).json({"message":err.message});
}
});

//login, failed to put it in a controller for now
router.post("/login", async (req, res) => {
  const { username, password } = req.body;

  const user = await Users.findOne({ where: { username: username } });

  if (!user) res.json({ error: "User Doesn't Exist" });

  bcrypt.compare(password, user.password).then(async (match) => {
    if (!match) res.json({ error: "Wrong Username And Password Combination" });
>>>>>>> 8ac287df8d967a9b300cdd8f22b62914acf90580

//register at /auth/register
router.post("/auth/register",registerRouter);

//login at /auth/login
router.post("/auth/login",registerRouter);

//infor abiout logged in user
router.get("/auth/user",registerRouter);

//find all users  at auth/users
router.get("/auth/users",registerRouter);

//get a specific user id
router.get("/auth/basicinfo/:id",registerRouter);
//update
router.put("/auth/update/:id",registerRouter);

//delete user by id at 3001/auth/delete/:id
router.delete("/auth/delete/:id",registerRouter);



module.exports = router;
