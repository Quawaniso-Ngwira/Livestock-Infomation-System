export const AUTH_STATE = "AUTH_STATE";

